
# Deploy Instructions (Render + Vercel + Z-API + MongoDB Atlas)

1. Configure MongoDB Atlas: crie cluster e obtenha MONGO_URL.
2. No Render: crie Web Service -> connect GitHub or upload repo.
   - Build command: pip install -r backend/requirements.txt
   - Start command: uvicorn app.main:app --host 0.0.0.0 --port 8000
   - Environment variables: MONGO_URL, DB_NAME, ZAPI_INSTANCE_ID, ZAPI_TOKEN, FRONTEND_URL, SECRET_KEY
3. On Vercel: import frontend folder, set NEXT_PUBLIC_API_URL to your backend URL.
4. In Z-API panel: set Webhook URL to https://<your-backend>/api/webhooks/whatsapp
5. Test with curl as explained in README.
