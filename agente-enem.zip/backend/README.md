
# Backend (FastAPI) - Agente ENEM

Como rodar local:
1. Copie .env.example para .env e preencha valores.
2. Instale dependências:
   pip install -r requirements.txt
3. Rode:
   uvicorn app.main:app --reload

Rotas principais:
- GET /api/health
- POST /api/webhooks/whatsapp  (Z-API webhook)
- POST /api/optout?phone=...
- GET  /api/welcome-message?phone=...
- GET  /api/ai-response?prompt=...

Substitua placeholders e configure Z-API conforme seu plano.
