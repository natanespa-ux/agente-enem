
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .routers import webhooks, optout, ai_agent
import os
from motor.motor_asyncio import AsyncIOMotorClient

app = FastAPI(title="Agente ENEM API")

# Mongo setup (reads MONGO_URL and DB_NAME)
MONGO_URL = os.getenv("MONGO_URL", "")
DB_NAME = os.getenv("DB_NAME", "agente_enem_db")
if MONGO_URL:
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]
else:
    db = None  # placeholder for local testing

app.include_router(webhooks.api_router, prefix="/api")
app.include_router(optout.api_router, prefix="/api")
app.include_router(ai_agent.api_router, prefix="/api")

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/health")
async def health():
    return {"status":"healthy", "db_connected": bool(db)}
