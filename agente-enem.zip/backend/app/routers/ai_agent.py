
from fastapi import APIRouter, Query
from fastapi.responses import JSONResponse
import os
import openai
api_router = APIRouter()
openai_api_key = os.getenv("OPENAI_API_KEY") or os.getenv("EMERGENT_LLM_KEY")
if openai_api_key:
    openai.api_key = openai_api_key

@api_router.get("/ai-response")
async def ai_response(prompt: str = Query(...)):
    if not openai_api_key:
        return JSONResponse(status_code=501, content={"error":"OpenAI key not configured"})
    try:
        resp = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role":"system","content":"Você é o Representante ENEM, objetivo de venda, direto e educado."},
                      {"role":"user","content":prompt}]
        )
        answer = resp["choices"][0]["message"]["content"]
        return JSONResponse(status_code=200, content={"answer": answer})
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})
