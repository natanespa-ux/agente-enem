
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
import logging, httpx, os
from datetime import datetime
from ...services import zapi

api_router = APIRouter()
logger = logging.getLogger("webhooks")
logger.setLevel(logging.INFO)

# greeting text (confirmed by user)
WELCOME_TEXT = (
    "Olá! 👋 Eu sou o Representante ENEM.\n"
    "Antes de começarmos, salve meu contato como *Representante ENEM* para receber o material completo.\n"
    "Digite SAIR a qualquer momento se não quiser continuar."
)

EXIT_KEYWORDS = ["sair", "remover", "cancelar", "parar"]

@api_router.post("/webhooks/whatsapp")
async def whatsapp_webhook(request: Request):
    try:
        data = await request.json()
        # Try common structures: data["message"]["text"], or data["body"]
        message = ""
        phone = ""
        if isinstance(data, dict):
            message = (data.get("message", {}).get("text") or data.get("body") or "").strip().lower()
            phone = data.get("message", {}).get("from") or data.get("from") or data.get("phone") or ""
        logger.info(f"Received message from {phone}: {message}")

        # Opt-out handling
        if any(k in message for k in EXIT_KEYWORDS):
            # call optout route
            async with httpx.AsyncClient() as client:
                await client.post(os.getenv("BACKEND_URL", "http://localhost:8000") + "/api/optout", params={"phone": phone})
            # send confirmation via Z-API
            try:
                await zapi.send_text(phone, "Tudo certo 👋 Você foi removido da nossa lista. Caso queira voltar, é só enviar 'voltar'.")
            except Exception as e:
                logger.error("Failed to send optout confirmation: %s", e)
            return JSONResponse(status_code=200, content={"action":"lead_removed"})

        # Welcome greeting for common greetings
        if message in ["oi", "olá", "ola", "bom dia", "boa tarde", "boa noite"]:
            try:
                await zapi.send_text(phone, WELCOME_TEXT)
            except Exception as e:
                logger.error("Failed to send welcome: %s", e)
            return JSONResponse(status_code=200, content={"action":"welcome_sent"})

        # "voltar" handling
        if "voltar" in message:
            try:
                await zapi.send_text(phone, "Bem-vindo de volta! 😊 Para garantir que receba tudo certinho, salve meu contato como Representante ENEM.")
            except Exception as e:
                logger.error("Failed to send voltar message: %s", e)
            return JSONResponse(status_code=200, content={"action":"reactivated"})

        # Default: forward to AI if configured, else default reply
        if os.getenv("OPENAI_API_KEY") or os.getenv("EMERGENT_LLM_KEY"):
            # call local ai endpoint
            try:
                async with httpx.AsyncClient() as client:
                    resp = await client.get(os.getenv("BACKEND_URL", "http://localhost:8000") + "/api/ai-response", params={"prompt": message})
                    ai_msg = resp.json().get("answer", "")
                    if ai_msg:
                        await zapi.send_text(phone, ai_msg)
                        return JSONResponse(status_code=200, content={"action":"ai_response"})
            except Exception as e:
                logger.error("AI call failed: %s", e)

        # Fallback generic sales CTA (tone B: natural and vendedor)
        cta = ("Olá! Posso te enviar agora o *Manual do ENEM Definitivo* por um preço especial? "
               "Responda SIM para receber o link de pagamento.")
        try:
            await zapi.send_text(phone, cta)
        except Exception as e:
            logger.error("Failed to send CTA: %s", e)
        return JSONResponse(status_code=200, content={"action":"cta_sent"})

    except Exception as e:
        logger.error("Webhook error: %s", e)
        return JSONResponse(status_code=500, content={"error": str(e)})
