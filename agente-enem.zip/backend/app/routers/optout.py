
from fastapi import APIRouter
from fastapi.responses import JSONResponse
from datetime import datetime
import os

api_router = APIRouter()

@api_router.post("/optout")
async def optout_user(phone: str):
    # This starter marks user as inactive in DB (placeholder: real DB logic goes here)
    # For now, just return success. Replace with DB update in production.
    return JSONResponse(status_code=200, content={"message": f"Phone {phone} marked as unsubscribed (placeholder)."})
