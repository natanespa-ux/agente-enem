
import os
import httpx
ZAPI_INSTANCE = os.getenv("ZAPI_INSTANCE_ID")
ZAPI_TOKEN = os.getenv("ZAPI_TOKEN")
# Example send function - adjust per your Z-API format
async def send_text(phone: str, text: str):
    if not ZAPI_INSTANCE or not ZAPI_TOKEN:
        raise RuntimeError("Z-API not configured")
    # Example endpoint format - adapt if your Z-API differs
    url = f"https://api.z-api.io/instances/{ZAPI_INSTANCE}/token/{ZAPI_TOKEN}/send-text"
    payload = {"phone": phone, "message": text}
    async with httpx.AsyncClient() as client:
        r = await client.post(url, json=payload, timeout=10)
        r.raise_for_status()
        return r.json()
