
export default function Home() {
  return (
    <main style={{padding:20,fontFamily:'Arial'}}>
      <h1>Atendente ENEM — Painel</h1>
      <p>Este é um painel mínimo. Conecte o backend definindo NEXT_PUBLIC_API_URL nas variáveis de ambiente.</p>
      <p>Use a página /leads para ver os leads (em desenvolvimento).</p>
    </main>
  )
}
