
Front-end minimal:
- Next.js app
- Configure NEXT_PUBLIC_API_URL to point to backend (ex: https://agente-enem.onrender.com)
