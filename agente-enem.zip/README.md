
# Agente ENEM — Projeto Full-stack (starter)

Este é um pacote *starter* para o **Atendente ENEM** (backend + frontend minimal) pronto para deploy em Render (backend) e Vercel (frontend).
Substitua placeholders em `.env.example` antes de subir.

Conteúdo:
- backend/: FastAPI app com webhook Z-API, opt-out e rota de boas-vindas.
- frontend/: Next.js app minimal (página de painel simples).
- deploy-instructions.md: passo-a-passo de deploy.
